# Projeto SO Console — Orquestrador Distribuído via Sockets TCP/IP

Sistema distribuído com orquestrador em Python que coordena N servidores de execução via sockets, aplicando estratégias de escalonamento (SJF, Round Robin, Prioridade, FIFO) e balanceamento com Quick Fit (Least Connections).

## Visão Geral
- **Processos servidores** (multiprocessing): cada servidor escuta em TCP e processa tarefas em **threads** (paralelismo real).
- **Orquestrador**: lê `tasks.json`, aloca tarefas, monitora carga, coleta métricas e imprime relatório final.
- **Protocolo**: mensagens JSON delimitadas por `\n` (uma por linha), full-duplex.

## Arquitetura
- 1 processo orquestrador + N processos servidores.
- Ponte socket por servidor (sender + receiver) com contabilidade de carga.
- Quick Fit adaptado: seleciona menor carga; desempate por maior capacidade e menor ID.
- Métricas: preempções, tempos de resposta, throughput.

## Estruturas
- `task_queues`: filas por servidor consumidas pela ponte sender.
- `server_load`: contadores de tarefas ativas por servidor (thread-safe).
- `lista_global_pendentes`: tarefas aguardando alocação.
- `concluidas`/`dados_concluidos`: resultados para relatório.

## Estratégias
- **SJF**: Shortest Job First (quantum=0, não-preemptivo).
- **ROUND_ROBIN**: quantum fixo (default 2s) com preempção cíclica.
- **PRIORIDADE**: ordena por prioridade (1 alta, 3 baixa).
- **FIFO**: ordem de chegada (quantum=0).

## Protocolo de Socket
- Request (servidor recebe): `{id, tempo_exec, tempo_restante?, prioridade}`
- Response (servidor envia):
  - `{"tipo":"CONCLUSAO", "req_id", "servidor_id", "tempo_final", "dados_originais"}`
  - `{"tipo":"PREEMPCAO", "req_id", "servidor_id", "tempo_restante", "dados_originais"}`

## Configuração (`tasks.json`)
```json
{
  "servidores": [
    {"id": 1, "capacidade": 2},
    {"id": 2, "capacidade": 2}
  ],
  "requisicoes": [
    {"id": 101, "tipo": "visao", "prioridade": 1, "tempo_exec": 8},
    {"id": 102, "tipo": "nlp", "prioridade": 3, "tempo_exec": 3}
  ]
}
```
- Portas: `get_port_for_server(id)` usa `5000 + id` (ex.: 5001, 5002...).
- Qualquer número de servidores/requisições é suportado.

## Como Executar (Windows CMD)
No diretório `Projeto_SO_console`:
```cmd
python -m venv .venv
.venv\Scripts\activate
python Projeto_SO_console\main.py
```
Siga o menu e escolha a estratégia (1-4).

## Relatório Final
- Requisições concluídas, tempo total, tempo médio de resposta, preempções, throughput.

## Acesso em LAN/VLAN (opcional)
- Para acessar servidores de sockets de outras máquinas, altere o bind em `main.py` de `('localhost', port)` para `('0.0.0.0', port)` e abra firewall:
```cmd
netsh advfirewall firewall add rule name="BSB Servers 5001-5010" dir=in action=allow protocol=TCP localport=5001-5010
```
- O orquestrador deve conectar usando o IP da máquina: `client_socket.connect(("<SEU_IP>", port))`.

## Troubleshooting
- Erro "Address already in use": aguarde alguns segundos; `SO_REUSEADDR` reduz `TIME_WAIT`.
- Conexão fecha imediatamente: verifique firewall e portas corretas.
- Baixo desempenho: ajuste `quantum`, capacidade dos servidores e número de threads.
