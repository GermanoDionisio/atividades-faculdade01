# Projeto SO Flask — UI Web + API do Orquestrador

Interface web em Flask sobre o scheduler distribuído (sockets TCP/IP) com **SSE em tempo real**, métricas avançadas e suporte dinâmico a N servidores.

## Sumário
- Visão Geral e Arquitetura
- Setup e Execução
- Endpoints de API
- `tasks.json` (Esquema e exemplo)
- Métricas e Visualização
- Acesso em LAN/VLAN
- Troubleshooting

## Visão Geral
- UI inicia/paralisa execução, escolhe estratégia/quantum e exibe métricas/logs.
- Backend (scheduler) roda com processos de servidores + threads de ponte.
- SSE entrega eventos em tempo real para a UI sem bloquear o backend.

## Arquitetura
- Comunicação: JSON sobre TCP, mensagens delimitadas por `\n`.
- Servidores: multi-thread por processo, uma thread por tarefa ativa.
- Balanceamento: Quick Fit (Least Connections) com desempate por capacidade e ID.
- Estratégias: `SJF`, `ROUND_ROBIN`, `PRIORIDADE`, `FIFO`.
- Logger: histórico textual + broadcast SSE (filas por assinante, não bloqueante).

## Estrutura do Projeto
```
Projeto_SO_flask/
  app.py                 # Flask (rotas REST + SSE)
  requirements.txt       # Dependências
  tasks.json             # Configuração (servidores+requisicoes) - aceita N itens
  backend/
    scheduler_backend.py # Núcleo do orquestrador + servidores TCP
  templates/
    base.html
    index.html           # UI responsiva que cria cards conforme servidores
  static/
    style.css            # Tema escuro, grid responsivo, tooltips
```

## Setup e Execução (Windows CMD)

```cmd
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Abra: http://127.0.0.1:5000
- Para usar outro `tasks.json`, informe caminho absoluto na UI.
- Estratégias válidas: `SJF`, `ROUND_ROBIN`, `PRIORIDADE`, `FIFO` (quantum=0).

## Endpoints de API
- `POST /start` — Body: `{strategy, quantum, tasksPath?}`. Inicia execução.
- `POST /stop` — Para execução atual.
- `GET /status` — Snapshot do sistema: `running`, `strategy`, `quantum`, `servers[]` com `carga`, `fila`, `active_ids`, `queue_ids`.
- `GET /metrics` — Métricas agregadas: `cpu_avg`, `mem_sys_percent_avg`, `mem_proc_mb_avg`, `mem_proc_mb_peak`, `throughput`, `preempcoes`, `tempo_total`, `media_resposta`, `finished`.
- `GET /results` — Lista de itens concluídos (metadados completos).
- `GET /events` — SSE com eventos `INICIO`, `ATRIBUICAO`, `PREEMPCAO`, `CONCLUSAO`, `FIM`.

## `tasks.json` (Esquema e exemplo)
- Servidores: `[{"id": int, "capacidade": int}]` — porta = `5000 + id`.
- Requisições: `[{"id": int, "tipo": str, "prioridade": 1|2|3, "tempo_exec": float}]`.
```json
{
  "servidores": [
    {"id": 1, "capacidade": 2},
    {"id": 2, "capacidade": 2},
    {"id": 3, "capacidade": 1},
    {"id": 4, "capacidade": 1}
  ],
  "requisicoes": [
    {"id": 101, "tipo": "visao_computacional", "prioridade": 1, "tempo_exec": 8},
    {"id": 102, "tipo": "nlp", "prioridade": 3, "tempo_exec": 3},
    ...
    {"id": 120, "tipo": "nlp", "prioridade": 1, "tempo_exec": 4}
  ]
}
```

## Métricas e Visualização
- Logs coloridos por tipo: ATRIBUICAO (azul), CONCLUSAO (verde), PREEMPCAO (rosa), ERRO (vermelho), FIM (amarelo).
- Chips mostram IDs em execução e próximos na fila por servidor.
- Cards de métricas com contraste e grade responsiva.

## Acesso em LAN/VLAN (opcional)
- Para que a UI seja acessível na rede, altere o bind do Flask para todas interfaces:
  - Em `app.py`: `app.run(host="0.0.0.0", port=5000, debug=True, threaded=True)`.
- Abra o firewall do Windows para a porta do Flask:
```cmd
netsh advfirewall firewall add rule name="BSB Flask 5000" dir=in action=allow protocol=TCP localport=5000
```
- Acesse de outros computadores via: `http://<SEU_IP>:5000`.

## Troubleshooting
- Porta ocupada: outra instância do Flask está rodando; encerre e tente novamente.
- SSE não atualiza: verifique se há execução ativa; o endpoint envia `keepalive` a cada 30s.
- Métricas zeradas: rode por tempo suficiente para coletar amostras (CPU/memória). 
- Performance: ajuste `quantum` e `capacidade` dos servidores no `tasks.json`.

## Notas
- Em Windows, `multiprocessing` inicia processos de servidores; o orquestrador e monitor rodam em threads.
- Portas de servidores: `5001`, `5002`, `5003`, ... (5000 + ID).
- Tempo total é congelado no fim da execução para relatórios fiéis.
